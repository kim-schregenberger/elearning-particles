# E-Learning: Animate particles with Tree.js

#Create a bouncing sphere with Three.js particles

#Setup
Download [Node.js](https://nodejs.org/en/download/).
Run the followed commands in integrated terminal:

``` bash
# Install
npm install

# Run the local server
npm run dev
```
